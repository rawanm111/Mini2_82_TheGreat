package com.example.ride_sharing.repositories;

import com.example.ride_sharing.models.Captain;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CaptainRepository extends JpaRepository<Captain, Long> {
    // You can define custom queries here if needed, like finding by registration number or rating range
}
